$(function() {

	window.Tweet = Backbone.Model.extend({
    });

});