$(function() {

	window.Tweets = Backbone.Collection.extend({
        model: Tweet
    });

});